<?php 
session_start();
if (isset($_SESSION['admin_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Admin') {
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Admin - Home</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/style.css">
	<link rel="icon" href="../logo.png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <?php 
        include "inc/navbar.php";
     ?>
     <div class="container mt-5 d-flex flex-column justify-content-center">
         <div class="container text-center d-flex flex-column justify-content-center align-items-center ">
             <div class="col-8 d-flex flex-column justify-content-center">
               <a href="teacher.php" 
                  class="col btn btn-dark m-2 py-3">
                 <i class="fa fa-user fs-1" aria-hidden="true"></i><br>
                  Teachers
               </a> 
               <a href="student.php" class="col btn btn-dark m-2 py-3">
                 <i class="fa fa-graduation-cap fs-1" aria-hidden="true"></i><br>
                  Students
               </a> 
               
              <!-- registar office -->

      
          
               

               <a href="message.php" class="col btn btn-dark m-2 py-3">
                 <i class="fa fa-envelope fs-1" aria-hidden="true"></i><br>
                  Message
               </a> 
               <a href="settings.php" class="col btn btn-primary m-2 py-3 col">
                 <i class="fa fa-cogs fs-1" aria-hidden="true"></i><br>
                  Settings
               </a> 
               <a href="../logout.php" class="col btn btn-warning m-2 py-3 col">
                 <i class="fa fa-sign-out fs-1" aria-hidden="true"></i><br>
                  Logout
               </a> 
             </div>
         </div>
     </div>

     <!-- footer -->
		<div class="container-fluid bg-dark text-white py-2 mt-5 mb-0 footer " style=" bottom: 0;">

      <table class="w-100 text-center">
      <tr>
        <td>  
        <img src="../logo.png" alt="" style="height: 120px;"><br>
        </td>
        <td class="h5">
        <a href="../contact-us.php" class=" active text-warning">CONTACT US</a> |
        <a href="../about-us.php" class=" active text-warning">ABOUT US</a> |
        <a href="" class=" active text-warning">PRIVACY POLICY</a>
        </td>
        <td class="fafaicon">
        FOLLOW US <br>
        <a href="#" class="fa fa-facebook" style="text-decoration: none;"></a>
        <a href="#" class="fa fa-twitter" style="text-decoration: none;"></a>
        <a href="#" class="fa fa-instagram" style="text-decoration: none;"></a>
        </td>
      </tr>
      </table>
      <hr>

      <p class="text-center m-3">© 2024. All rights reserved.</p>

      </div>  
      <!-- footer end-->
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>	
    <script>
        $(document).ready(function(){
             $("#navLinks li:nth-child(1) a").addClass('active');
        });
    </script>

</body>
</html>
<?php 

  }else {
    header("Location: ../login.php");
    exit;
  } 
}else {
	header("Location: ../login.php");
	exit;
} 

?>